function AdminPage() {
    return <h1>The Admin Portal</h1>
} 

export default AdminPage;