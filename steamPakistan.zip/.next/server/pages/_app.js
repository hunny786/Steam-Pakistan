(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 64:
/***/ ((module) => {

// Exports
module.exports = {
	"navLink": "navbar_navLink__29RCt"
};


/***/ }),

/***/ 242:
/***/ ((module) => {

// Exports
module.exports = {
	"navLink": "topnav_navLink__ii0WN",
	"navbarTopnav": "topnav_navbarTopnav__99W5E"
};


/***/ }),

/***/ 32:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
;// CONCATENATED MODULE: external "react-bootstrap/Container"
const Container_namespaceObject = require("react-bootstrap/Container");
var Container_default = /*#__PURE__*/__webpack_require__.n(Container_namespaceObject);
;// CONCATENATED MODULE: external "react-bootstrap/Nav"
const Nav_namespaceObject = require("react-bootstrap/Nav");
var Nav_default = /*#__PURE__*/__webpack_require__.n(Nav_namespaceObject);
;// CONCATENATED MODULE: external "react-bootstrap/Navbar"
const Navbar_namespaceObject = require("react-bootstrap/Navbar");
var Navbar_default = /*#__PURE__*/__webpack_require__.n(Navbar_namespaceObject);
// EXTERNAL MODULE: ./components/header/topnav.module.css
var topnav_module = __webpack_require__(242);
var topnav_module_default = /*#__PURE__*/__webpack_require__.n(topnav_module);
;// CONCATENATED MODULE: ./components/header/topnav.js







class TopNav extends external_react_.Component {
    render() {
        return /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Fragment, {
            children: /*#__PURE__*/ jsx_runtime_.jsx((Navbar_default()), {
                className: (topnav_module_default()).navbarTopnav,
                expand: "lg",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Navbar_default()).Toggle, {
                            "aria-controls": "basic-navbar-nav"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Navbar_default()).Collapse, {
                            className: "justify-content-end",
                            id: "basic-navbar-nav",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Nav_default()), {
                                className: "align-items-center",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Nav_default()).Link, {
                                        className: `${(topnav_module_default()).navLink} d-flex align-items-end`,
                                        href: "#",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "../../icons/navicons-faqs.png"
                                            }),
                                            "FAQs"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Nav_default()).Link, {
                                        className: `${(topnav_module_default()).navLink} d-flex align-items-end`,
                                        href: "#",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "../../icons/navicons-resources.png"
                                            }),
                                            "Resources"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Nav_default()).Link, {
                                        className: `${(topnav_module_default()).navLink} d-flex align-items-end`,
                                        href: "#",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "../../icons/navicons-register.png"
                                            }),
                                            "Register"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Nav_default()).Link, {
                                        className: `${(topnav_module_default()).navLink} d-flex align-items-end me-0`,
                                        href: "#",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "../../icons/navicons-login.png"
                                            }),
                                            "Adeel"
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        });
    }
}
/* harmony default export */ const topnav = (TopNav);

// EXTERNAL MODULE: ./components/header/navbar.module.css
var navbar_module = __webpack_require__(64);
var navbar_module_default = /*#__PURE__*/__webpack_require__.n(navbar_module);
;// CONCATENATED MODULE: ./components/header/navbar.js






class NavbarView extends external_react_.Component {
    render() {
        return /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Fragment, {
            children: /*#__PURE__*/ jsx_runtime_.jsx((Navbar_default()), {
                bg: "light",
                expand: "lg",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Navbar_default()).Brand, {
                            href: "#home",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "../../images/logo-web-large.png"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Navbar_default()).Toggle, {
                            "aria-controls": "basic-navbar-nav"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Navbar_default()).Collapse, {
                            className: "justify-content-end",
                            id: "basic-navbar-nav",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Nav_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Nav_default()).Link, {
                                        className: `${(navbar_module_default()).navLink} active`,
                                        href: "#",
                                        children: "Home"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Nav_default()).Link, {
                                        className: `${(navbar_module_default()).navLink} `,
                                        href: "#",
                                        children: "About"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Nav_default()).Link, {
                                        className: `${(navbar_module_default()).navLink} `,
                                        href: "#",
                                        children: "Tutorials"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Nav_default()).Link, {
                                        className: `${(navbar_module_default()).navLink}  me-0`,
                                        href: "#",
                                        children: "Innovation"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Nav_default()).Link, {
                                        className: `${(navbar_module_default()).navLink}  me-0`,
                                        href: "#",
                                        children: "Guides"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Nav_default()).Link, {
                                        className: `${(navbar_module_default()).navLink}  me-0`,
                                        href: "#",
                                        children: "Practicals"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Nav_default()).Link, {
                                        className: `${(navbar_module_default()).navLink}  me-0`,
                                        href: "#",
                                        children: "Contact"
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        });
    }
}
/* harmony default export */ const navbar = (NavbarView);

;// CONCATENATED MODULE: ./components/footer/footer.js


class Footer extends external_react_.Component {
    state = {};
    render() {
        return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "row align-items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12 col-sm text-center text-sm-start mb-3 mb-sm-0",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "#",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "../../images/logo-web-small.png"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12 col-sm text-center mb-3 mb-sm-0",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Supported by: Pak Alliance for Maths and Science"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12 col-sm",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "social-icons text-center text-sm-end",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "../../icons/icon-faceb.png"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "../../icons/icon-twitter.png"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "#",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "../../icons/icon-youtube.png"
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        });
    }
}
/* harmony default export */ const footer = (Footer);

;// CONCATENATED MODULE: ./components/layout/layout.js





const Layout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(topnav, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("header", {
                className: "sticky-top",
                children: /*#__PURE__*/ jsx_runtime_.jsx(navbar, {})
            }),
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(footer, {})
        ]
    });
};
/* harmony default export */ const layout = (Layout);

;// CONCATENATED MODULE: ./pages/_app.js






function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "STEM"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "stylesheet",
                        href: "https://use.typekit.net/jyt4vtq.css"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(layout, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                })
            })
        ]
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(32));
module.exports = __webpack_exports__;

})();