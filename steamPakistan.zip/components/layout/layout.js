import { Fragment } from "react";
import TopNav from "../header/topnav";
import NavbarView from "../header/navbar";
import Footer from "../footer/footer";

const Layout = ( {children} ) => {
    return ( 
        <Fragment>
            <TopNav />
            <header className="sticky-top">
                <NavbarView />
            </header>
            { children }
            <Footer />
        </Fragment>
     );
}
 
export default Layout;